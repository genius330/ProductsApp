﻿using System;

namespace products
{
    public class Напитки
    {
        public string Название { get; set; }
        public double Калории { get; set; }
        public bool Алкогольный { get; set; }

        public Напитки(string название, double калории, bool алкогольный)
        {
            Название = название;
            Калории = калории;
            Алкогольный = алкогольный;
        }
    }
}