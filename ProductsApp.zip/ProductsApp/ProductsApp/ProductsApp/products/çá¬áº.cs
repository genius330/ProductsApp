﻿using System;
using System.Collections.Generic;

namespace products
{
    public class Заказ
    {
        private List<(string Название, double Цена)> Позиции { get; set; }
        private double ОбщаяСумма { get; set; }

        public Заказ()
        {
            Позиции = new List<(string, double)>();
            ОбщаяСумма = 0;
        }

        public void ДобавитьПозицию(string название, double цена)
        {
            Позиции.Add((название, цена));
            ОбщаяСумма += цена;
        }

        public void ВывестиЧек()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n" + new string('=', 40));
            Console.WriteLine("          ИТОГОВЫЙ ЧЕК");
            Console.WriteLine(new string('=', 40));
            Console.ResetColor();

            foreach (var позиция in Позиции)
            {
                Console.WriteLine($"{позиция.Название} - {позиция.Цена:F2} руб.");
            }

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine($"\nИТОГО К ОПЛАТЕ: {ОбщаяСумма:F2} руб.");
            Console.ResetColor();
        }
    }
}