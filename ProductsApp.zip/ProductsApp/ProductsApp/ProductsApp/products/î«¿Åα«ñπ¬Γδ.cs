﻿using System;
using System.Collections.Generic;

namespace products
{
    public class МоиПродукты
    {
        public double МаксБелки { get; set; }
        public double МаксЖиры { get; set; }
        public double МаксУглеводы { get; set; }
        public double МаксКалории { get; set; }
        public List<Продукт> СписокПродуктов { get; set; }

        public МоиПродукты(double максБелки, double максЖиры, double максУглеводы, double максКалории)
        {
            МаксБелки = максБелки;
            МаксЖиры = максЖиры;
            МаксУглеводы = максУглеводы;
            МаксКалории = максКалории;
            СписокПродуктов = new List<Продукт>();
        }

        public void ДобавитьПродукт(Продукт продукт)
        {
            if (!продукт.ПроверитьДанные())
            {
                Console.WriteLine("Ошибка: данные продукта некорректны.");
                return;
            }

            if (продукт.Белки > МаксБелки)
            {
                Console.WriteLine($"Ошибка: слишком много белков ({продукт.Белки} > {МаксБелки})");
                return;
            }

            if (продукт.Жиры > МаксЖиры)
            {
                Console.WriteLine($"Ошибка: слишком много жиров ({продукт.Жиры} > {МаксЖиры})");
                return;
            }

            if (продукт.Углеводы > МаксУглеводы)
            {
                Console.WriteLine($"Ошибка: слишком много углеводов ({продукт.Углеводы} > {МаксУглеводы})");
                return;
            }

            if (продукт.Калории > МаксКалории)
            {
                Console.WriteLine($"Ошибка: слишком много калорий ({продукт.Калории} > {МаксКалории})");
                return;
            }

            СписокПродуктов.Add(продукт);
            Console.WriteLine($"Продукт '{продукт.Название}' успешно добавлен!");
        }

        public void ВывестиНазвания()
        {
            Console.WriteLine("Список продуктов:");
            foreach (var продукт in СписокПродуктов)
            {
                Console.WriteLine(продукт.Название);
            }
        }
    }
}