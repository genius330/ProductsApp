﻿using System;

namespace products
{
    public class Блюдо
    {
        public string Название { get; set; }
        public bool Вегетарианское { get; set; }
        public double Калории { get; set; }
        public string Тип { get; set; } // Мясо, Рыба, Другое

        public Блюдо(string название, bool вегетарианское, double калории, string тип)
        {
            Название = название;
            Вегетарианское = вегетарианское;
            Калории = калории;
            Тип = тип;
        }
    }
}