﻿using System;
using System.Collections.Generic;

namespace products
{
    public class Ресторан
    {
        public string Город { get; set; }
        public List<Блюдо> МенюБлюд { get; set; }
        public List<Напитки> МенюНапитков { get; set; }
        public double Цена { get; set; }
        public Блюдо БлюдоОтШефа { get; set; }

        // 👇 ОСТАВЬ ТОЛЬКО ЭТОТ КОНСТРУКТОР
        public Ресторан(string город, double базоваяЦена)
        {
            Город = город;
            МенюБлюд = new List<Блюдо>();
            МенюНапитков = new List<Напитки>();
            Цена = базоваяЦена;
            БлюдоОтШефа = null; // 👈 Это важно — инициализируем
        }

        public double ПолучитьЦену(int час)
        {
            double цена = Город == "Москва" ? Цена * 1.1 : Цена;

            // Скидка 20% с 15 до 18 часов
            if (час >= 15 && час <= 18)
            {
                цена *= 0.8;
            }

            return цена;
        }

        public void ДобавитьБлюдо(Блюдо блюдо)
        {
            МенюБлюд.Add(блюдо);
        }

        public void ДобавитьНапиток(Напитки напиток)
        {
            МенюНапитков.Add(напиток);
        }

        public void ВывестиМеню(int час)
        {
            Console.WriteLine($"\n=== Меню ресторана в {Город} ===");

            if (час >= 7 && час <= 11)
            {
                Console.WriteLine("Утреннее меню:");
                foreach (var блюдо in МенюБлюд)
                    Console.WriteLine($"{блюдо.Название} - {ПолучитьЦену(час):F2} руб.");
            }

            if (час >= 12 && час <= 15)
            {
                Console.WriteLine("Бизнес-ланчи:");
                foreach (var блюдо in МенюБлюд)
                    Console.WriteLine($"{блюдо.Название} - {ПолучитьЦену(час):F2} руб.");
            }

            if (час >= 15 && час <= 24)
            {
                Console.WriteLine("Обеденное/вечернее меню:");
                foreach (var блюдо in МенюБлюд)
                    Console.WriteLine($"{блюдо.Название} - {ПолучитьЦену(час):F2} руб.");
            }

            // Блюдо от шефа
            if (БлюдоОтШефа != null)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n⭐ БЛЮДО ОТ ШЕФА:");
                Console.WriteLine($"{БлюдоОтШефа.Название} - {ПолучитьЦену(час):F2} руб.");
                Console.ResetColor();
            }

            Console.WriteLine("\nНапитки (всегда доступны):");
            foreach (var напиток in МенюНапитков)
                Console.WriteLine($"{напиток.Название} - {ПолучитьЦену(час):F2} руб.");
        }
    }
}